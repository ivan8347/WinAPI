﻿=== Bubble Red Glow Unit Numbers Icon Set ===

By: 

Download: https://www.rw-designer.com/icon-set/bubble-red-glow-unit-numbers

Author's description:

Following my preset set of "Bubble Red Glow Alphabet Letters", I have created this "Bubble Red Glow Unit Numbers" icon set which follows the same style and red color glow theme. This set of numeric numbers, are an extension to the letters, so if you need numbers in this sort of theme, then here it is.

This set of "Bubble Red Glow Unit Numbers" follows the same guidelines as with the "Bubble Red Glow Alphabet Letters", so make sure to follow the instructions carefully.

Please note that this set is the last in this series and this set is part of the same theme color as the previous set in the same family. There is only one color variant of this family of letters and numbers. I shall not make any more colors for this theme set of icons.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.